﻿namespace eCommerce.Data.Enum
{
    public enum ProductCategory
    {
        Adidas = 1,
        Nike,
        Jordan,
        Puma,
        Converse,
        Yeezy
    }
}

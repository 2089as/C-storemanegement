﻿
using eCommerce.Data.Base;
using eCommerce.Models;

namespace eCommerce.Data.Services
{
    public interface ICitiesService : IEntityBaseReponsitory<City>
    {
    }
}

﻿using eCommerce.Data.Base;
using eCommerce.Models;

namespace eCommerce.Data.Services
{
    public interface ICompaniesService : IEntityBaseReponsitory<Company>
    {
    }
}

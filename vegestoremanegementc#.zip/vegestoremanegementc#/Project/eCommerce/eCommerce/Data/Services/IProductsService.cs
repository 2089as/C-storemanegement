﻿using eCommerce.Data.Base;
using eCommerce.Data.ViewModels;
using eCommerce.Models;

namespace eCommerce.Data.Services
{
    public interface IProductsService : IEntityBaseReponsitory<Product>
    {
        Task <Product> GetProductByIdAsync(int id);
        Task <NewProductsDropdownsVM> GetNewProductDropdownsValues();
        Task AddNewProductAsync(NewProductVM data);
        Task UpdateProductAsync(NewProductVM data);
        Task DeleteProductAsync(int id);
    }
}

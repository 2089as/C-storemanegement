﻿using eCommerce.Data.Base;
using eCommerce.Models;

namespace eCommerce.Data.Services
{
    public interface IStoresService : IEntityBaseReponsitory<Store>
    {
    }
}
